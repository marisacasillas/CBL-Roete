#Loading packages and setting paths
library(ggplot2)
library(lme4)
library(grid)
library(gridExtra)
library(stringr)
library(jtools)
library(lattice)

#Plot layout settings
basic.theme <- theme(
  panel.background = element_rect(
    fill = "transparent",colour = NA),
  panel.grid.major = element_line(colour = "grey95"),
  panel.grid.minor = element_blank(),
  plot.background = element_rect(
    fill = "transparent",colour = NA),
  legend.background = element_rect(
    fill="transparent"),
  legend.text = element_text(size=24),
  legend.title = element_text(size=30),
  legend.key.height = unit(2, "lines"),
  legend.key = element_rect(colour = NA, fill = NA),
  axis.text.x = element_text(size=30, angle=45, hjust=1),
  axis.title.x = element_text(size=30),
  axis.text.y = element_text(size=28),
  axis.title.y = element_text(size=32),
  strip.text = element_text(size=30),
  panel.spacing = unit(2, "lines"))

#load the child utterance data
setwd("/Volumes/ladd/workspaces/ld-ingroe/projects/modeling_roete/03-raw_data/03-analysis_scripts/CBL-master/localsampledcorpus/childcopy/")
plot.path <- "/Volumes/ladd/workspaces/ld-ingroe/projects/modeling_roete/04-analysis/paper/results/localsampledcorpus/"

#open file and extract child name and age
filenames <- list.files(pattern="*.txt")
data <- NULL
for (file in filenames){
  temp.data <- read.delim(file)
  colnames(temp.data) <- c("utterance")
  temp.data$child <- unlist(strsplit(unlist(strsplit(file, "_age"))[1],"child"))[2]
  temp.data$age <- unlist(strsplit(unlist(strsplit(file, "_age"))[2],".txt"))
  data <- rbind(data,temp.data)
}

#converting age variable to numeric values and months into years
data$age <- gsub("_", ".", data$age)
data$age <- gsub("6", "5", data$age)
data$age <- as.numeric(data$age)
data$numwords <- data$numwords <- str_count(data$utterance," ")

#plot
##Make plot: x-axis: age, y-axis: utterance length in words, collapsed over all children
plotdata_local_uttlength <- aggregate(data$numwords, by = c(list(age=data$age)),FUN=sum)
colnames(plotdata_local_uttlength)[2] <- "total_uttlength"
plotdata_temp <- aggregate(data$numwords, by = c(list(age=data$age)), FUN = function(x){NROW(x)})
colnames(plotdata_temp)[2] <- "total_num_utterances"
plotdata_local_uttlength <- merge(plotdata_local_uttlength,plotdata_temp, by = c("age"))
plotdata_local_uttlength$averagelength <- (plotdata_local_uttlength$total_uttlength/plotdata_temp$total_num_utterances)

plot.local.uttlength <- ggplot(plotdata_local_uttlength, 
                               aes(x=age, y = averagelength)) + 
  geom_line(size = 1.5) + basic.theme + theme(axis.text.x = element_text(size=22)) + 
  #coord_cartesian(ylim=(c(0,100))) + 
  xlab("\nAge (years)") + 
  ylab("Average number of words \n in child utterance\n") + 
  #ggtitle("Local sampling") + 
  basic.theme + theme(axis.text.x = element_text(size=22)) + 
  theme(plot.title = element_text(size=32, face = "bold.italic", hjust = 0.5, margin=margin(b = 30, unit = "pt")))

#Save plot
png(paste(plot.path,
          "plotlocaluttlength.png", sep=""),
    width=900,height=500,units="px",
    bg = "transparent")
plot.local.uttlength+theme_apa()
dev.off()
plot.local.uttlength+theme_apa()

#load the child utterance data
setwd("/Volumes/ladd/workspaces/ld-ingroe/projects/modeling_roete/03-raw_data/03-analysis_scripts/CBL-master/cumulativesampledcorpus/childcopy/")
plot.path <- "/Volumes/ladd/workspaces/ld-ingroe/projects/modeling_roete/04-analysis/paper/results/accumulativesampledcorpus/"

#open file and extract child name and age
filenames <- list.files(pattern="*.txt")
data <- NULL
for (file in filenames){
  temp.data <- read.delim(file)
  colnames(temp.data) <- c("utterance")
  temp.data$child <- unlist(strsplit(unlist(strsplit(file, "_age"))[1],"child"))[2]
  temp.data$age <- unlist(strsplit(unlist(strsplit(file, "_age"))[2],".txt"))
  data <- rbind(data,temp.data)
}

#converting age variable to numeric values and months into years
data$age <- gsub("_", ".", data$age)
data$age <- gsub("6", "5", data$age)
data$age <- as.numeric(data$age)
data$numwords <- data$numwords <- str_count(data$utterance," ")

#plot
##Make plot: x-axis: age, y-axis: utterance length in words, collapsed over all children
plotdata_cumu_uttlength <- aggregate(data$numwords, by = c(list(age=data$age)),FUN=sum)
colnames(plotdata_cumu_uttlength)[2] <- "total_uttlength"
plotdata_temp <- aggregate(data$numwords, by = c(list(age=data$age)), FUN = function(x){NROW(x)})
colnames(plotdata_temp)[2] <- "total_num_utterances"
plotdata_cumu_uttlength <- merge(plotdata_cumu_uttlength,plotdata_temp, by = c("age"))
plotdata_cumu_uttlength$averagelength <- (plotdata_cumu_uttlength$total_uttlength/plotdata_temp$total_num_utterances)

plot.cumu.uttlength <- ggplot(plotdata_cumu_uttlength, 
                               aes(x=age, y = averagelength)) + 
  geom_line(size = 1.5) + basic.theme + theme(axis.text.x = element_text(size=22)) + 
  #coord_cartesian(ylim=(c(0,100))) + 
  xlab("\nAge (years)") + 
  ylab("Average number of words \n in child utterance\n") + 
  #ggtitle("Local sampling") + 
  basic.theme + theme(axis.text.x = element_text(size=22)) + 
  theme(plot.title = element_text(size=32, face = "bold.italic", hjust = 0.5, margin=margin(b = 30, unit = "pt")))

#Save plot
png(paste(plot.path,
          "plotcumuuttlength.png", sep=""),
    width=900,height=500,units="px",
    bg = "transparent")
plot.cumu.uttlength+theme_apa()
dev.off()
plot.cumu.uttlength+theme_apa()

plot.both.uttlength <- ggplot() +
  geom_line(data = plotdata_local_uttlength, aes(x=age, y = averagelength, color = "local")) +
  geom_line(data = plotdata_cumu_uttlength, aes(x=age, y = averagelength, color = "cumulative")) + 
  geom_line(size = 1.5) + basic.theme + theme(axis.text.x = element_text(size=22)) +
  #scale_colour_manual(name = "Child:", values = groupcolours) + 
  coord_cartesian(ylim=(c(0,10))) + 
  xlab("\nAge (years)") + 
  ylab("Average number of words \n in child utterance\n") + 
  ggtitle("Child utterance length") + 
  guides(color = guide_legend(reverse = TRUE)) +
  basic.theme + theme(axis.text.x = element_text(size=22)) + 
  theme(plot.title = element_text(size=32, face = "bold.italic", hjust = 0.5, margin=margin(b = 30, unit = "pt")))

#Save plot
png(paste(plot.path,
          "plotbothuttlength.png", sep=""),
    width=900,height=500,units="px",
    bg = "transparent")
plot.both.uttlength+theme_apa()
dev.off()
plot.both.uttlength+theme_apa()